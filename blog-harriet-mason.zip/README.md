# My Blog


This is the blog of Harriet Mason.
The URL of this blog is https://etc5523-2021.github.io/blog-harriet-mason/posts/2021-09-04-blog-post-1/.

## Blog Post 1

This assessment is due Wed Sep 8 2021 11.55PM AEST.

My selected country is Ecuador.

The relevant blog post for this assessment is in 2021-09-04-blog-post-1.html


## Blog Post 2

This assessment is due Fri Sep 17 2021 11.55PM AEST.

My selected country is [FILL].

The relevant blog post for this assessment is in [FILL].html

- [ ] Selected a new country
- [ ] Data Story 1
- [ ] Data Story 2
- [ ] Graph 1
- [ ] Graph 2
- [ ] Submitted the entire blog to Moodle

